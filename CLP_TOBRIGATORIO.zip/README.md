# Monte Carlo Matrix Multiplication

A simple comparison between a C implementation and a Fortran


Students
* Guilherme Souza
* Thiago Heron
* Igor Barbosa

