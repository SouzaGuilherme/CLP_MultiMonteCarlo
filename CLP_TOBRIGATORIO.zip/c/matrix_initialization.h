#ifndef MATRIX_INITIALIZATION_H
#define MATRIX_INITIALIZATION_H

#include <stdlib.h>
#include <time.h>

void geraMatrizRand(int ** matrix, int n); 

#endif // ! MATRIX_INITIALIZATION_H
